package ingest
type Event struct { ClientIP, CountryISO, City, ASOrg string; Lat,Lon float32; ASN uint32 }
