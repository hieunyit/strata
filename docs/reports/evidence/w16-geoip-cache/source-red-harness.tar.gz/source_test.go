package ingest
import("testing"; "net")
type countReader struct{ calls int }
func(r *countReader)Lookup(net.IP)(*GeoIPLocation,error){r.calls++;return &GeoIPLocation{CountryISO:"GB"},nil}
func TestSourceReturnedValueIsolation(t *testing.T){
 e:=NewGeoIPEnricher(NewMockGeoIPReader(map[string]GeoIPLocation{"81.2.69.142":{CountryISO:"GB"}}))
 first:=e.Resolve("81.2.69.142"); first.CountryISO="US"
 if got:=e.Resolve("81.2.69.142");got==nil||got.CountryISO!="GB"{t.Fatalf("caller poisoned cached country: %+v",got)}
}
func TestSourceCanonicalCacheKey(t *testing.T){
 r:=&countReader{};e:=NewGeoIPEnricher(r)
 e.Resolve("81.2.69.142");e.Resolve("[::ffff:81.2.69.142]:443")
 if r.calls!=1{t.Fatalf("same address consumed multiple cache keys: lookups=%d",r.calls)}
}
func TestSourceEnrichClearsForgedMissingLocation(t *testing.T){
 e:=NewGeoIPEnricher(NewMockGeoIPReader(nil));evt:=&Event{ClientIP:"192.0.2.1",CountryISO:"US",City:"forged"};e.Enrich(evt)
 if evt.CountryISO!=""||evt.City!=""{t.Fatalf("unknown lookup preserved agent-supplied location: %+v",evt)}
}
